from flask import Flask,render_template,redirect,request, url_for, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy 
import json 


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgres://qgejdtoiecguax:972ade6d739de4ff4dde8a8ae1555e51764336c0d5630ec37683f48ec05b5d12@ec2-174-129-33-207.compute-1.amazonaws.com:5432/d92hq0j95hh0o6'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 
db = SQLAlchemy(app)

class JsonModel(object):
    def as_dict(self):
       return {c.name: getattr(self, c.name) for c in self.__table__.columns}

class Person(db.Model, JsonModel):
    __tablename__ = 'persons'
    id = db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(), nullable=False)


    def __repr__(self):
        return f'<Person ID: {self.id}, name: {self.name}>'



'''create table, and drop table if exists'''
db.create_all()

@app.route('/event/create',methods=['POST'])
def create_events():
    description = request.get_json().get("name")
    todo = Person(name = description)
    db.session.add(todo)
    db.session.commit()
    #return redirect(url_for('index'))
    return jsonify({
        "name": request.get_json().get("name"),
        "status": 200
    })

@app.route('/event/get', methods=['GET'])
def get_events():
    person = Person.query.all()
    return json.dumps([u.as_dict() for u in Person.query.all()])



@app.route('/')
def index():
    person = Person.query.all()
    #return render_template('index.html',data=person)
    return jsonify({
        'name': 'success',
        'value':[p for p in person]
    })



if __name__ == '__main__':
    app.run()